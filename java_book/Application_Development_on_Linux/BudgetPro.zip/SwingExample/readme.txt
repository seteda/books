This is a set of files for the Swing Example as described in chapter 16 of
"Java(tm) Application Development on Linux(r)"
by Albing and Schwarz,
published by PrenticeHall PTR

Files                       Description
gnu_gpl_2.txt               a copy of the GNU General Public License Ver. 2.
                            This is the license under which this software is made
                            available to you.

readme.txt                  This file.

net/multitool/core:         Directory tree leading to the files
                            for the core of the application:
    Account.java            The basic account class
    Payment.java            The basic payment class
    User.java               The basic User class
    Vendor.java             The basic Vendor class

./net/multitool/gui:        Directory tree leading to the GUI pieces:
    AcctDialog.java         The helper dialog class
    BudgetPro.java          The main Swing GUI class

The source lisitngs in Appendix B of the book are those
of the BudgetPro.java and AcctDialog.java.

You will need one more class to make all these compile: SpringUtilities.java
That is code that you will have to download from Sun, and it can be found at:
  http://java.sun.com/docs/books/tutorial/uiswing/layout/example-1dot4/SpringUtilities.java

Save the source for SpringUtilities into net/multitool/gui and it should all compile.
From this directory, compile it all, as this command shows:

  $ javac net/multitool/gui/BudgetPro.java
  $

Then to execute the gui, run it, as shown here, with an amount to budget (e.g. 500000):

  $ java net.multitool.gui.BudgetPro  500000



