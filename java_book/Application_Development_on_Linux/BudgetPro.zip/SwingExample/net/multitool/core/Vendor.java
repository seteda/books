package net.multitool.core;        // Copyright (C) 2004 by Carl Albing and Michael Schwarz
                                   // Licensed under the terms of the GNU GPL version 2.  
import net.multitool.util.*;
import java.util.*;

public class Vendor {
   private String vendorName;
}


