package net.multitool.core;        // Copyright (C) 2004 by Carl Albing and Michael Schwarz
                                   // Licensed under the terms of the GNU GPL version 2.  
import net.multitool.util.*;
import java.util.*;

public class
User
{
   private String name;
   private Account home;        // TODO: implement

   public
   User(String username)
   {
      name = username;
   }

   public String
   toString()
   {
      return name;
   }

} // class User

