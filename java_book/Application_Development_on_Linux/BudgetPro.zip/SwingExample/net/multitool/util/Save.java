package net.multitool.util;        // Copyright (C) 2004 by Carl Albing and Michael Schwarz
                                   // Licensed under the terms of the GNU GPL version 2.  
// import

public class
Save
{
    double sum;
    double irate;
    double pay;
    double cost;
    int months;

    Save(double amt, double rate, double paymnt)
    {
        this.months = 0;
        pay = paymnt;
        sum = pay;
        irate = 1.0+(rate/12.0);

        while (sum < amt) {
            months++;
            sum = (sum*irate)+pay;
        }
    }

    /**
     * Returns the overall savings - principle and interest.
     */
    public double
    getCost()
    {
        return sum;

    } // getCost

    /**
     * Returns the length, in months, of the payback period.
     */
    public double
    getLength()
    {
        return months;

    } // getLength

    public static void
    main(String [] args)
    {
        Save d = new Save( 1000.00, 0.12, 25.00);
        System.out.println("In " + d.getLength() + " months");
        System.out.println("You can save $"+d.getCost());
    } // main

} // class Save
