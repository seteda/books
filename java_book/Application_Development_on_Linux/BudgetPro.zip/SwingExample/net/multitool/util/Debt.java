package net.multitool.util;        // Copyright (C) 2004 by Carl Albing and Michael Schwarz
                                   // Licensed under the terms of the GNU GPL version 2.  
// import

public class
Debt
{
    double debt;
    double irate;
    double pay;
    double cost;
    int months;

    Debt(double amt, double rate, double paymnt)
    {
        this.months = 0;
        debt = amt;
        pay = paymnt;
        irate = rate/12.0;

        cost = debt;
        while (debt > 0) {
            months++;
            cost += debt*irate;
            debt -= pay;
        }
    }

    Debt(SAMoney samt, double rate, double paymnt, boolean flag)
    {
        this(samt.doubleValue(), rate, paymnt);
    }

    /**
     * Returns the overall cost of the load - principle and interest.
     */
    public double
    getCost()
    {
        return cost;

    } // getCost

    /**
     * Returns the length, in months, of the payback period.
     */
    public double
    getLength()
    {
        return months;

    } // getLength

    public static void
    main(String [] args)
    {
        Debt d = new Debt( 1000.00, 0.12, 25.00);
        System.out.println(d.getLength());
        System.out.println(d.getCost());
    } // main

} // class Debt
