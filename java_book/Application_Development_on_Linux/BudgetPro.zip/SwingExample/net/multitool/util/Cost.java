package net.multitool.util;        // Copyright (C) 2004 by Carl Albing and Michael Schwarz
                                   // Licensed under the terms of the GNU GPL version 2.  
public class Cost {
	private int numMonths;
	private double realPrice;

	public Cost(int mn, double rp)
	{
		numMonths = mn;
		realPrice = rp;
	}

	public int getMonths() {
		return numMonths;
	}

	public double getPrice() {
		return realPrice;
	}
}

