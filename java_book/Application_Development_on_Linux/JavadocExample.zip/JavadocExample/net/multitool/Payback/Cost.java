package net.multitool.Payback;     // Copyright (C) 2004 by Carl Albing and Michael Schwarz
                                   // Licensed under the terms of the GNU GPL version 2.  
import java.math.*;

public class Cost {
	private int numMonths;
	private BigDecimal realPrice;

	public Cost(int mn, BigDecimal rp)
	{
		numMonths = mn;
		realPrice = rp;
	}

	public int getMonths() {
		return numMonths;
	}

	public BigDecimal getPrice() {
		return realPrice;
	}
}

