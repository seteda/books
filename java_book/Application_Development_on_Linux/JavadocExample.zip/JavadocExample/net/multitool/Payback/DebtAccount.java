package net.multitool.Payback;     // Copyright (C) 2004 by Carl Albing and Michael Schwarz
                                   // Licensed under the terms of the GNU GPL version 2.  
import java.math.*;

public class DebtAccount extends Account {

	public DebtAccount()
	{
	}

	public DebtAccount(String n, double r)
	{
		super(n,r);
	}

	public Cost getCost(Purchase p)
	{
		return new Cost(1, new BigDecimal(1.0));
	}
}

